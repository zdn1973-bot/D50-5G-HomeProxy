#!/bin/sh

echo "==========================================================="
echo " Konfiguracja LAN/zapory pod IPv6 (Orange PL) "
echo "==========================================================="

echo "[1/3] LAN: ip6assign=64, ip6class=local"
uci set network.lan.ip6assign='64'
uci set network.lan.ip6class='local'

echo "[2/3] Zapora: masq6=1 na strefie WAN"
WAN_ZONE=$(uci show firewall | grep "\.name='wan'" | cut -d'.' -f2 | head -n 1)
if [ -n "$WAN_ZONE" ]; then
	uci set firewall.${WAN_ZONE}.masq6='1'
else
	uci set firewall.@zone[1].masq6='1'
fi

echo "[3/3] odhcpd: ra_default=1 na interfejsie LAN"
uci set dhcp.lan.ra_default='1'

uci commit network
uci commit firewall
uci commit dhcp

echo "-----------------------------------------------------------"
echo " Przeładowywanie usług: network, firewall, odhcpd "
echo "-----------------------------------------------------------"
/etc/init.d/network restart
/etc/init.d/firewall restart
/etc/init.d/odhcpd restart

echo "==========================================================="
echo " GOTOWE. Ustawienia LAN/zapory zapisane trwale w UCI."
echo " Interfejs modemu (MTU/forwarding/accept_ra) skonfiguruj"
echo " zaznaczając 'Fix IPv6 configuration' w ustawieniach"
echo " interfejsu quectel."
echo "==========================================================="
